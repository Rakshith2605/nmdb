# Package initialization
"""
Examples module for the MCP library.

This module provides example usage of the MCP library.
"""

from .example_queries import run_examples

__all__ = ["run_examples"]